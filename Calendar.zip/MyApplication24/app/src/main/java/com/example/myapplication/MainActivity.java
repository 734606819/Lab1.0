package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.app.usage.UsageEvents;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.provider.CalendarContract;
import android.provider.Settings;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

public class MainActivity extends AppCompatActivity {
 CalendarView z; DBOpenHelper dbOpenHelper;
    Button k; TextView CurrentDate; Button zz,xx;
    private static Context mContext;
    private static MainActivity instance;
    public static final String PRIMARY_CHANNEL = "default";
    public static final String SECONDARY_CHANNEL = "second";
    private static final int MAX_CALENDAR_DAYS = 42;
    private static final String TAG = MainActivity.class.getSimpleName();
    private static final int NOTI_PRIMARY1 = 1100;
    private static final int NOTI_PRIMARY2 = 1101;
    private static final int NOTI_SECONDARY1 = 1200;
    private static final int NOTI_SECONDARY2 = 1201;
    public static int eventID = 0;

    private SharedPreferences sharedPreferences;
    private NotificationManager manager;
    private NotificationHelper noti;
    ImageButton NextButton, PreviousButton;
    Calendar calendar = Calendar.getInstance(Locale.ENGLISH);
    Context context;GridView gridView;
    SimpleDateFormat dateFormat = new SimpleDateFormat("MMMM yyyy", Locale.ENGLISH);
    SimpleDateFormat monthFormat = new SimpleDateFormat("MMMM", Locale.ENGLISH);
    SimpleDateFormat monthFormat1 = new SimpleDateFormat("MM", Locale.ENGLISH);
    SimpleDateFormat yearFormat = new SimpleDateFormat("yyyy", Locale.ENGLISH);
    SimpleDateFormat eventDateFormate = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
    SimpleDateFormat dateFormat1=new SimpleDateFormat("dd",Locale.ENGLISH);
    SimpleDateFormat formate =new SimpleDateFormat ("yyyy", Locale.ENGLISH);
    MyGridAdapter myGridAdapter;
    AlertDialog alertDialog;
    List<Date> dates = new ArrayList<>();
    List<Events> eventslist = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        instance = this;

        //  z=findViewById(R.id.calendarView);
        NextButton = findViewById(R.id.nextBtn);
        gridView = findViewById(R.id.gradView);
        PreviousButton = findViewById(R.id.previouusBtn);
       // CurrentDate = findViewById(R.id.currentday);
       // gridView = view.findViewById(R.id.gradView);
        k=findViewById(R.id.evvvv);CurrentDate =findViewById(R.id.currentday);
        zz=findViewById(R.id.ek);
        //xx=findViewById(R.id.ekk);
        SetUpCalendar();
        CollectEventsPerMonth(monthFormat.format(calendar.getTime()),yearFormat.format(calendar.getTime()));
        final List<Events> eventslist = new ArrayList<>();


        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setCancelable(true);
                final View addView = LayoutInflater.from(parent.getContext()).inflate(R.layout.add_newevent_layout, null);
              //  Toast.makeText(MainActivity.this, "Event Saved", Toast.LENGTH_SHORT).show();
             final EditText EventName = addView.findViewById(R.id.eventname);
             final TextView EventTime = addView.findViewById(R.id.eventtime);
              ImageButton SetTime = addView.findViewById(R.id.seteventtime);
               final CheckBox alarmMe = addView.findViewById(R.id.alarmme);

                final CheckBox send = addView.findViewById(R.id.Sendmessage);
               Calendar dateCalendar = Calendar.getInstance();
               dateCalendar.setTime(dates.get(position));
               // alarmYear = dateCalendar.get(Calendar.YEAR);
               // alarmMonth = dateCalendar.get(Calendar.MONTH);
               // alarmDay = dateCalendar.get(Calendar.DAY_OF_MONTH);
                Button AddEvent = addView.findViewById(R.id.addevent);
                noti = new NotificationHelper(MainActivity.this);
                SetTime.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Calendar calendar = Calendar.getInstance();
                     int hours = calendar.get(Calendar.HOUR_OF_DAY);
                     int minutes = calendar.get(Calendar.MINUTE);
                        TimePickerDialog timePickerDialog = new TimePickerDialog(addView.getContext(), R.style.Theme_AppCompat_Dialog, new TimePickerDialog.OnTimeSetListener() {
                            @Override
                            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                                Calendar c = Calendar.getInstance();
                                c.set(Calendar.HOUR_OF_DAY, hourOfDay);
                                c.set(Calendar.MINUTE, minute);
                                c.setTimeZone(TimeZone.getDefault());
                                SimpleDateFormat hformate = new SimpleDateFormat("K:mm a", Locale.ENGLISH);
                                String event_Time = hformate.format(c.getTime());
                                EventTime.setText(event_Time);
                               // alarmHour=c.get(Calendar.HOUR_OF_DAY);
                               // alarmmin=c.get(Calendar.MINUTE);
                            }
                        }, hours, minutes, false);
                        timePickerDialog.show();
                    }
                });

                final String date = eventDateFormate.format(dates.get(position));
                final String month = monthFormat.format(dates.get(position));
                final String year = yearFormat.format(dates.get(position));
                final String dd = dateFormat1.format(dates.get(position));
                final String date1 = eventDateFormate.format(dates.get(position));
                final String Mon = monthFormat1.format(dates.get(position));
                AddEvent.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (checkSelfPermission(Manifest.permission.WRITE_CALENDAR) != PackageManager.PERMISSION_GRANTED) {
                            // TODO: Consider calling
                            //    Activity#requestPermissions
                            // here to request the missing permissions, and then overriding
                            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                            //                                          int[] grantResults)
                            // to handle the case where the user grants the permission. See the documentation
                            // for Activity#requestPermissions for more details.

                            ActivityCompat.requestPermissions(MainActivity.this,
                                    new String[]{Manifest.permission.WRITE_CALENDAR},1 );
                            return;




                        }
                       // eventslist.clear();
                       // dbOpenHelper = new DBOpenHelper(context);
                        //SQLiteDatabase database = dbOpenHelper.getReadableDatabase();

                        // Cursor
                        //  Cursor cursor = dbOpenHelper.fetch(database);
                        // Cursor cursor=dbOpenHelper.ReadEventsperMonth1(Month,year,database);
                        //Cursor cursor =dbOpenHelper.ReadEventsperMonth(Month, year,database);
                       // while (cursor.moveToNext()) {
                         //   String event = cursor.getString(cursor.getColumnIndex(DBStructure.EVENT));
                         //   String time = cursor.getString(cursor.getColumnIndex(DBStructure.TIME));
                         //   String date = cursor.getString(cursor.getColumnIndex(DBStructure.DATE));
                         //   String month = cursor.getString(cursor.getColumnIndex(DBStructure.MONTH));
                         //   String Year = cursor.getString(cursor.getColumnIndex(DBStructure.YEAR));
                         //   Events events = new Events(event, time, date, month, Year);
                            //CalendarContract.Events events = new CalendarContract.Events(event, time, date, month, Year);
                           // eventslist.add(events);
                            //   Toast.makeText(MainActivity.this, event, Toast.LENGTH_SHORT).show();
                           Calendar c = Calendar.getInstance();


                            ContentResolver cr = getContentResolver();
                       //     ContentValues contentValues = new ContentValues();
                            Calendar beginTime = Calendar.getInstance();

                           // int OP= Integer.parseInt(Year);
                       // final String date = eventDateFormate.format(dates.get(position));
                      //  final String month = monthFormat.format(dates.get(position));
                      //  final String year = yearFormat.format(dates.get(position));
                       // final String date1 = eventDateFormate.format(dates.get(position+1));
                        int dat=Integer.parseInt(dd);
                       int mon=Integer.parseInt(Mon)-1;
                        int yea=Integer.parseInt(year);
                        int monn=Integer.parseInt(Mon);
                            beginTime.set(yea, mon, dat, 0, 0);
                            Calendar endTime = Calendar.getInstance();
                            endTime.set(yea, mon, dat, 0, 0);
                            ContentValues values = new ContentValues();
                            values.put(CalendarContract.Events.DTSTART, beginTime.getTimeInMillis());
                             values.put(CalendarContract.Events.DTEND, endTime.getTimeInMillis());
                            values.put(CalendarContract.Events.TITLE, EventName.getText().toString());
                            // values.put(CalendarContract.Events.DESCRIPTION, "Successful Startups");
                            values.put(CalendarContract.Events.CALENDAR_ID, 3);
                            values.put(CalendarContract.Events.EVENT_TIMEZONE, "Europe/London");
                            //  values.put(CalendarContract.Events.EVENT_LOCATION, "London");
                            values.put(CalendarContract.Events.GUESTS_CAN_INVITE_OTHERS, "1");
                            values.put(CalendarContract.Events.GUESTS_CAN_SEE_GUESTS, "1");

                            cr.insert(CalendarContract.Events.CONTENT_URI, values);
                       // cursor.close();
                       // dbOpenHelper.close();

                        if (send.isChecked()) {
                            if (alarmMe.isChecked()) {
                                SaveEvent(EventName.getText().toString(), EventTime.getText().toString(), date, month, year);
                                SetUpCalendar();
                                // Intent intent1=new Intent(context.getApplicationContext(),MainActivity.class);
                                //intent1.putExtra("event",EventName.getText().toString());
                                //intent1.putExtra("time",EventTime.getText().toString());
                                //intent1.putExtra("date",date);
                                //intent1.putExtra("month",month);
                                //intent1.putExtra("year",year);
                                Calendar calendar = Calendar.getInstance();
                                //calendar.set(alarmYear, alarmMonth, alarmDay, alarmHour, alarmmin);
                                // setAlarm(calendar,EventName.getText().toString(),EventTime.getText().toString(),getRequestCode(date,EventName.getText().toString(),EventTime.getText().toString()));
                                // sync(date, date1, EventName.getText().toString());
                                alertDialog.dismiss();
                                CollectEventsPerMonth(monthFormat.format(calendar.getTime()), yearFormat.format(calendar.getTime()));
                                Notification.Builder nb = null;
                                Toast.makeText(MainActivity.this, "ok, alarm set ", Toast.LENGTH_LONG).show();
                                final EditText hhhhh = addView.findViewById(R.id.Alarmhour);
                                final EditText mmmmmm = addView.findViewById(R.id.Alarmmin);
                                int hooo = Integer.parseInt(hhhhh.getText().toString());
                                int miiii = Integer.parseInt(mmmmmm.getText().toString());
                                Calendar calendar11 = Calendar.getInstance();
                                calendar11.setTimeInMillis(System.currentTimeMillis());
                                calendar11.set(Calendar.DAY_OF_MONTH,dat );
                                calendar11.set(Calendar.MONTH,mon );
                                calendar11.set(Calendar.YEAR,yea );
                                calendar11.set(Calendar.HOUR_OF_DAY, hooo);
                                calendar11.set(Calendar.MINUTE, miiii);
                                calendar11.set(Calendar.SECOND, 0);

                                Intent intent1 = new Intent(MainActivity.this, AlarmReceiver.class);
                                PendingIntent pendingIntent = PendingIntent.getBroadcast(MainActivity.this, 0, intent1, PendingIntent.FLAG_UPDATE_CURRENT);
                                AlarmManager alarmManager = (AlarmManager) MainActivity.this.getSystemService(MainActivity.this.ALARM_SERVICE);
                                alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, calendar11.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent);
                                String AK = "" + EventTime.getText().toString() + "  at  " + date;
                             //   nb = noti.getNotification2(EventName.getText().toString(), AK);
                              //  if (nb != null) {
                              //      noti.notify(17, nb);
                              //  }




                            } else {
                                // ADDData(EventName.getText().toString(), EventTime.getText().toString(), date, month, year,"off");
                                //boolean isInserted= myDB.insertData(EventName.getText().toString(), EventTime.getText().toString(), date, month, year,"off");
                                SaveEvent(EventName.getText().toString(), EventTime.getText().toString(), date, month, year);
                                SetUpCalendar();
                                alertDialog.dismiss();
                                CollectEventsPerMonth(monthFormat.format(calendar.getTime()), yearFormat.format(calendar.getTime()));
                                // Notification.Builder nb = null;
                                //  nb = noti.getNotification1("dsad", "dsad");
                                //  if (nb != null) {
                                //    noti.notify(15, nb);
                            }
                            // if (isInserted=true)
                            //{Toast.makeText(context, "Event saved", Toast.LENGTH_SHORT).show();}
                            final EditText Nu=addView.findViewById(R.id.phonenumber);
                            final EditText Me=addView.findViewById(R.id.meessage);
                            String ME="dsadasdsad";
                      //    btn_send(Nu.getText().toString(),Me.getText().toString());

                          //  Intent iii = new Intent(MainActivity.this, Alarm.class);
                          //  String kt=Nu.getText().toString();
                          //  String me=Me.getText().toString();
                          //  iii.putExtra("NU", kt);
                           // iii.putExtra("ME", me);




                            //  else  {Toast.makeText(context, "Event not saved", Toast.LENGTH_SHORT).show();}
                        }

                    else
                    {

                        if (alarmMe.isChecked()) {
                            SaveEvent(EventName.getText().toString(), EventTime.getText().toString(), date, month, year);
                            SetUpCalendar();
                            // Intent intent1=new Intent(context.getApplicationContext(),MainActivity.class);
                            //intent1.putExtra("event",EventName.getText().toString());
                            //intent1.putExtra("time",EventTime.getText().toString());
                            //intent1.putExtra("date",date);
                            //intent1.putExtra("month",month);
                            //intent1.putExtra("year",year);
                            Calendar calendar = Calendar.getInstance();
                            //calendar.set(alarmYear, alarmMonth, alarmDay, alarmHour, alarmmin);
                            // setAlarm(calendar,EventName.getText().toString(),EventTime.getText().toString(),getRequestCode(date,EventName.getText().toString(),EventTime.getText().toString()));
                            // sync(date, date1, EventName.getText().toString());
                            alertDialog.dismiss();
                            CollectEventsPerMonth(monthFormat.format(calendar.getTime()), yearFormat.format(calendar.getTime()));
                            Notification.Builder nb = null;String KL= "    " +dat + " at " +mon + " "+yea+ " " ;
                            Toast.makeText(MainActivity.this, "ok, alarm set ", Toast.LENGTH_LONG).show();
                         //   int hooo = Integer.parseInt(hhhhh.getText().toString());
                         //   int miiii = Integer.parseInt(mmmmmm.getText().toString());
                            Calendar calendar11 = Calendar.getInstance();
                            calendar11.setTimeInMillis(System.currentTimeMillis());
                            calendar11.set(Calendar.DAY_OF_MONTH,dat );
                            calendar11.set(Calendar.MONTH,mon );
                            calendar11.set(Calendar.YEAR,yea );
                           //calendar11.set(Calendar.HOUR_OF_DAY, hooo);
                          //  calendar11.set(Calendar.MINUTE, miiii);
                            calendar11.set(Calendar.SECOND, 0);

                            Intent intent1 = new Intent(MainActivity.this, AlarmReceiver.class);
                            PendingIntent pendingIntent = PendingIntent.getBroadcast(MainActivity.this, 0, intent1, PendingIntent.FLAG_UPDATE_CURRENT);
                            AlarmManager alarmManager = (AlarmManager) MainActivity.this.getSystemService(MainActivity.this.ALARM_SERVICE);
                            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, calendar11.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent);



                            Toast.makeText(MainActivity.this, KL, Toast.LENGTH_LONG).show();

                            String AK = "" + EventTime.getText().toString() + "  at  " + date;
                           // nb = noti.getNotification2(EventName.getText().toString(), AK);
                          //  if (nb != null) {
                              //  noti.notify(17, nb);
                          //  }

                        } else {
                            // ADDData(EventName.getText().toString(), EventTime.getText().toString(), date, month, year,"off");
                            //boolean isInserted= myDB.insertData(EventName.getText().toString(), EventTime.getText().toString(), date, month, year,"off");
                            SaveEvent(EventName.getText().toString(), EventTime.getText().toString(), date, month, year);
                            SetUpCalendar();
                            alertDialog.dismiss();
                            CollectEventsPerMonth(monthFormat.format(calendar.getTime()), yearFormat.format(calendar.getTime()));
                            // Notification.Builder nb = null;
                            //  nb = noti.getNotification1("dsad", "dsad");
                            //  if (nb != null) {
                            //    noti.notify(15, nb);
                        }

                    }}
                    //  SaveEvent(EventName.getText().toString(), EventTime.getText().toString(), date, month, year);
                    //   SetUpCalendar();
                    //   alertDialog.dismiss();
                });
                builder.setView(addView);
                alertDialog = builder.create();
                alertDialog.show();
            }});
       /* xx.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View v) {


                // cursor.close();
                // dbOpenHelper.close();


            }});*/
        gridView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
               String date = eventDateFormate.format(dates.get(position));

               CollectEventByDate(date);
                //Toast.makeText(MainActivity.this, "555", Toast.LENGTH_SHORT).show();
              // AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
               // builder.setCancelable(true);
              //  View showView = LayoutInflater.from(parent.getContext()).inflate(R.layout.show_events_rowlayout,null);
              //  RecyclerView recyclerView =showView.findViewById(R.id.EventsRV);
                //recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));
              //  RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(showView.getContext().t);
               // recyclerView.setLayoutManager(layoutManager);




              //  recyclerView.setHasFixedSize(true);
               // EventRecyclerAdapter eventRecyclerAdapter = new EventRecyclerAdapter(MainActivity.this,CollectEventByDate(date));
              //  recyclerView.setAdapter(eventRecyclerAdapter);
               // eventRecyclerAdapter.notifyDataSetChanged()builder.setView(showView);
                //alertDialog = builder.create();
                //alertDialog.show();

               // TextView Events = showView.findViewById(R.id.eventname);
               // TextView Time  =showView.findViewById(R.id.evenTimee);
               // TextView Date = showView.findViewById(R.id.eventdate);
                return  true;



            }
        });
        PreviousButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calendar.add(Calendar.MONTH, -1);
                SetUpCalendar();

            }
        });
        NextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calendar.add(Calendar.MONTH, 1);
                SetUpCalendar();
            }
        });
 k.setOnClickListener(new View.OnClickListener() {
     @Override

     public void onClick(View v) {
         Intent i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
         i.putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
         startActivity(i);
         /*if (checkSelfPermission(Manifest.permission.WRITE_CALENDAR) != PackageManager.PERMISSION_GRANTED) {
             // TODO: Consider calling
             //    Activity#requestPermissions
             // here to request the missing permissions, and then overriding
             //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
             //                                          int[] grantResults)
             // to handle the case where the user grants the permission. See the documentation
             // for Activity#requestPermissions for more details.

             ActivityCompat.requestPermissions(MainActivity.this,
                     new String[]{Manifest.permission.WRITE_CALENDAR},1 );
             return;




         }
         ContentResolver cr = getContentResolver();
         ContentValues contentValues = new ContentValues();

         Calendar beginTime = Calendar.getInstance();
         String Year= "2019";
         int op =Integer.parseInt(Year);
         beginTime.set(op, 07, 04, 9, 30);

         Calendar endTime = Calendar.getInstance();
         endTime.set(2019, 07, 4, 7, 35);

         ContentValues values = new ContentValues();
         values.put(CalendarContract.Events.DTSTART, beginTime.getTimeInMillis());
         values.put(CalendarContract.Events.DTEND, endTime.getTimeInMillis());
         values.put(CalendarContract.Events.TITLE, "Tech Stores");
         values.put(CalendarContract.Events.DESCRIPTION, "Events from custom calendars");
         values.put(CalendarContract.Events.CALENDAR_ID, 2);
         values.put(CalendarContract.Events.EVENT_TIMEZONE, "Europe/London");
         values.put(CalendarContract.Events.EVENT_LOCATION, "London");
         values.put(CalendarContract.Events.GUESTS_CAN_INVITE_OTHERS, "1");
         values.put(CalendarContract.Events.GUESTS_CAN_SEE_GUESTS, "1");
         cr.insert(CalendarContract.Events.CONTENT_URI, values);*/

     }

 });


 zz.setOnClickListener(new View.OnClickListener() {
        @Override

        public void onClick(View v) {
            ComponentName cn;
            Intent i = new Intent();
            cn = new ComponentName("com.google.android.calendar", "com.android.calendar.LaunchActivity");
            i.setComponent(cn);
            startActivity(i);
         /*if (checkSelfPermission(Manifest.permission.WRITE_CALENDAR) != PackageManager.PERMISSION_GRANTED) {
             // TODO: Consider calling
             //    Activity#requestPermissions
             // here to request the missing permissions, and then overriding
             //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
             //                                          int[] grantResults)
             // to handle the case where the user grants the permission. See the documentation
             // for Activity#requestPermissions for more details.

             ActivityCompat.requestPermissions(MainActivity.this,
                     new String[]{Manifest.permission.WRITE_CALENDAR},1 );
             return;




         }
         ContentResolver cr = getContentResolver();
         ContentValues contentValues = new ContentValues();

         Calendar beginTime = Calendar.getInstance();
         String Year= "2019";
         int op =Integer.parseInt(Year);
         beginTime.set(op, 07, 04, 9, 30);

         Calendar endTime = Calendar.getInstance();
         endTime.set(2019, 07, 4, 7, 35);

         ContentValues values = new ContentValues();
         values.put(CalendarContract.Events.DTSTART, beginTime.getTimeInMillis());
         values.put(CalendarContract.Events.DTEND, endTime.getTimeInMillis());
         values.put(CalendarContract.Events.TITLE, "Tech Stores");
         values.put(CalendarContract.Events.DESCRIPTION, "Events from custom calendars");
         values.put(CalendarContract.Events.CALENDAR_ID, 2);
         values.put(CalendarContract.Events.EVENT_TIMEZONE, "Europe/London");
         values.put(CalendarContract.Events.EVENT_LOCATION, "London");
         values.put(CalendarContract.Events.GUESTS_CAN_INVITE_OTHERS, "1");
         values.put(CalendarContract.Events.GUESTS_CAN_SEE_GUESTS, "1");
         cr.insert(CalendarContract.Events.CONTENT_URI, values);*/

        }

    });}

    private void SaveEvent(String  event,String time,String date, String month,String year){

        dbOpenHelper = new DBOpenHelper(this);
        SQLiteDatabase database = dbOpenHelper.getWritableDatabase();
        dbOpenHelper.SaveEvent(event,time,date,month,year,database);
        dbOpenHelper.close();
        //Toast.makeText(this, "Event Saved", Toast.LENGTH_SHORT).show();

        //  {Toast.makeText(context, "Event didnt saved", Toast.LENGTH_SHORT).show();}
        //}

    }
    private void CollectEventsPerMonth(String Month, String year) {
       eventslist.clear();

        dbOpenHelper = new DBOpenHelper(this);

        SQLiteDatabase database = dbOpenHelper.getReadableDatabase();
        // Cursor
        //  Cursor cursor = dbOpenHelper.fetch(database);
        // Cursor cursor=dbOpenHelper.ReadEventsperMonth1(Month,year,database);
        Cursor cursor =dbOpenHelper.ReadEventsperMonth(Month, year,database);
        while (cursor.moveToNext()) {


            String event = cursor.getString(cursor.getColumnIndex(DBStructure.EVENT));
            String time = cursor.getString(cursor.getColumnIndex(DBStructure.TIME));
            String date = cursor.getString(cursor.getColumnIndex(DBStructure.DATE));
            String month = cursor.getString(cursor.getColumnIndex(DBStructure.MONTH));
            String Year = cursor.getString(cursor.getColumnIndex(DBStructure.YEAR));
            Events events = new Events(event, time, date, month, Year);
            //CalendarContract.Events events = new CalendarContract.Events(event, time, date, month, Year);
            eventslist.add(events);
         //   Toast.makeText(MainActivity.this, event, Toast.LENGTH_SHORT).show();
        }
        cursor.close();
        dbOpenHelper.close();
    }
    private void up(String Month, String year) {
        eventslist.clear();
        dbOpenHelper = new DBOpenHelper(this);
        SQLiteDatabase database = dbOpenHelper.getReadableDatabase();
        if (checkSelfPermission(Manifest.permission.WRITE_CALENDAR) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    Activity#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for Activity#requestPermissions for more details.

            ActivityCompat.requestPermissions(MainActivity.this,
                    new String[]{Manifest.permission.WRITE_CALENDAR},1 );
            return;




        }
        // Cursor
        //  Cursor cursor = dbOpenHelper.fetch(database);
        // Cursor cursor=dbOpenHelper.ReadEventsperMonth1(Month,year,database);
        Cursor cursor =dbOpenHelper.ReadEventsperMonth(Month, year,database);
        while (cursor.moveToNext()) {
            String event = cursor.getString(cursor.getColumnIndex(DBStructure.EVENT));
            String time = cursor.getString(cursor.getColumnIndex(DBStructure.TIME));
            String date = cursor.getString(cursor.getColumnIndex(DBStructure.DATE));
            String month = cursor.getString(cursor.getColumnIndex(DBStructure.MONTH));
            String Year = cursor.getString(cursor.getColumnIndex(DBStructure.YEAR));
            Events events = new Events(event, time, date, month, Year);
            //CalendarContract.Events events = new CalendarContract.Events(event, time, date, month, Year);
            eventslist.add(events);
            //   Toast.makeText(MainActivity.this, event, Toast.LENGTH_SHORT).show();
            ContentResolver cr = getContentResolver();
            ContentValues contentValues = new ContentValues();
            Calendar beginTime = Calendar.getInstance();
            int OP= Integer.parseInt(Year);
            beginTime.set(2019, 11, 24, 9, 30);
           Calendar endTime = Calendar.getInstance();
            endTime.set(2019, 11, 25, 7, 35);
            ContentValues values = new ContentValues();
            values.put(CalendarContract.Events.DTSTART, beginTime.getTimeInMillis());
           // values.put(CalendarContract.Events.DTEND, endTime.getTimeInMillis());
            values.put(CalendarContract.Events.TITLE, event);
           // values.put(CalendarContract.Events.DESCRIPTION, "Successful Startups");
            values.put(CalendarContract.Events.CALENDAR_ID, 2);
            values.put(CalendarContract.Events.EVENT_TIMEZONE, event);
          //  values.put(CalendarContract.Events.EVENT_LOCATION, "London");
            values.put(CalendarContract.Events.GUESTS_CAN_INVITE_OTHERS, "1");
            values.put(CalendarContract.Events.GUESTS_CAN_SEE_GUESTS, "1");

            cr.insert(CalendarContract.Events.CONTENT_URI, values);
        }
        cursor.close();
        dbOpenHelper.close();
    }
    private void CollectEventByDate(String date) {
        eventslist.clear();

        dbOpenHelper = new DBOpenHelper(this);

        SQLiteDatabase database = dbOpenHelper.getReadableDatabase();
        // Cursor
        //  Cursor cursor = dbOpenHelper.fetch(database);
        // Cursor cursor=dbOpenHelper.ReadEventsperMonth1(Month,year,database);
        Cursor cursor =dbOpenHelper.ReadEvents(date,database);
        while (cursor.moveToNext()) {


            String event = cursor.getString(cursor.getColumnIndex(DBStructure.EVENT));
            String time = cursor.getString(cursor.getColumnIndex(DBStructure.TIME));
            String date1 = cursor.getString(cursor.getColumnIndex(DBStructure.DATE));
            String month = cursor.getString(cursor.getColumnIndex(DBStructure.MONTH));
            String Year = cursor.getString(cursor.getColumnIndex(DBStructure.YEAR));
            //Events events = new Events(event, time, date1, month, Year);
            //CalendarContract.Events events = new CalendarContract.Events(event, time, date, month, Year);
            //eventslist.add(events);
            String KL= "Event name is  " +event + " at " +time + " "+date1+ " " + month+ " " +Year;
            Toast.makeText(MainActivity.this, KL, Toast.LENGTH_LONG).show();
        }
        cursor.close();
        dbOpenHelper.close();
    }
    public void btn_send (String nu,String Me) {
        int permissionCheck = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS);
        if (permissionCheck == PackageManager.PERMISSION_GRANTED){
           MyMessage(nu,Me);
        }
else
        {

            ActivityCompat.requestPermissions(this,new String[] {Manifest.permission.SEND_SMS},0);

        }

    }
    private void MyMessage(String nu,String Me) {


        String phoneNumber = nu;
        String Message = Me;

            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, Message, null, null);
            Toast.makeText(this, "Message send", Toast.LENGTH_SHORT).show();

        }

    private void Sync(String  event,String time,String date, String month,String year){
        if (checkSelfPermission(Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    Activity#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for Activity#requestPermissions for more details.

            ActivityCompat.requestPermissions(MainActivity.this,
                    new String[]{Manifest.permission.READ_CALENDAR},1 );
            return;

        }

        dbOpenHelper = new DBOpenHelper(this);
        SQLiteDatabase database = dbOpenHelper.getWritableDatabase();
        dbOpenHelper.SaveEvent(event,time,date,month,year,database);
        dbOpenHelper.close();
        String[] projection = new String[]{CalendarContract.Events._ID, CalendarContract.Events.CALENDAR_ID, CalendarContract.Events.TITLE, CalendarContract.Events.DESCRIPTION, CalendarContract.Events.DTSTART, CalendarContract.Events.DTEND, CalendarContract.Events.ALL_DAY, CalendarContract.Events.EVENT_LOCATION, CalendarContract.Events.RRULE, CalendarContract.Events.DURATION};

        //   String selection = "(( " + CalendarContract.Events.DTSTART + " >= " + startTime.getTimeInMillis() + " ) AND ( " + CalendarContract.Events.DTSTART + " <= " + endTime.getTimeInMillis() + " ) AND ( " + CalendarContract.Events.CALENDAR_ID + " = " + LOCAL_CAL_ACCOUNT_ID + " ) )";
Cursor cursor;
        cursor = getContentResolver().query(CalendarContract.Events.CONTENT_URI, projection, null, null, null);
        Log.i(">>>",cursor.toString());
        //  cursor = getContentResolver().query(CalendarContract.Events.CONTENT_URI, null, null, null, null);
            while (cursor.moveToNext()) {
                if (cursor != null) {
                    int id_1 = cursor.getColumnIndex(CalendarContract.Events.CALENDAR_ID);
                    int id_2 = cursor.getColumnIndex(CalendarContract.Events.TITLE);
                    int id_3 = cursor.getColumnIndex(CalendarContract.Events.DTSTART);
                    int id_4 = cursor.getColumnIndex(CalendarContract.Events.EVENT_LOCATION);
                    final Calendar cal = Calendar.getInstance();
                    cal.setTimeInMillis(id_3);
                    Date date1 = cal.getTime();
                   // mHour = date.getHours();
                  //  mMinute = date.getMinutes();
                    String idValue = cursor.getColumnName(id_1);
                    String titleValue = cursor.getString(id_2);
                    String descriptionValue = cursor.getString(id_3);
                    String eventValue = cursor.getString(id_4);
                    Toast.makeText(MainActivity.this, idValue + " , " + titleValue + " , " + descriptionValue + " , " + eventValue, Toast.LENGTH_LONG).show();


                } else {
                    Toast.makeText(MainActivity.this, "No event", Toast.LENGTH_SHORT).show();

                    //Toast.makeText(this, "Event Saved", Toast.LENGTH_SHORT).show();

                    //  {Toast.makeText(context, "Event didnt saved", Toast.LENGTH_SHORT).show();}
                    //}

                }

            }}
    private void SetUpCalendar() {
        String currentDate = dateFormat.format(calendar.getTime());
        CurrentDate.setText(currentDate);
        dates.clear();
        Calendar monthCalendar = (Calendar) calendar.clone();
        monthCalendar.set(Calendar.DAY_OF_MONTH, 1);
        int FirstDayofMonth = monthCalendar.get(Calendar.DAY_OF_WEEK) - 1;
        monthCalendar.add(Calendar.DAY_OF_MONTH, -FirstDayofMonth);
        myGridAdapter = new MyGridAdapter(this, dates, calendar, eventslist);
        gridView.setAdapter(myGridAdapter);
        //  CollectEventByDate(null);
        // CollectEventsPerMonth(String.valueOf(11),String.valueOf(2019));
        // //
        // CollectEventsPerMonth(monthFormat.format(calendar.getTime()),yearFormat.format(calendar.getTime()));
        while (dates.size() < MAX_CALENDAR_DAYS) {
            dates.add(monthCalendar.getTime());
            monthCalendar.add(Calendar.DAY_OF_MONTH, 1);


        }

    }}

