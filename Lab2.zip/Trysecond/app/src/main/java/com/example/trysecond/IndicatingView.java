package com.example.trysecond;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.PorterDuff;
import android.util.AttributeSet;
import android.view.View;

public class IndicatingView extends View {

    public static final int NOTEXECUTED =0;
    public static final int SUCCESS =1;
    public static final int FAILED =2;
    public static final int exx=3;
    int state=NOTEXECUTED;
    public IndicatingView(Context context){super(context);}
    public IndicatingView(Context context, AttributeSet attrs){super(context,attrs);}
    public IndicatingView(Context context,AttributeSet attrs,int defStyleAttr){super(context,attrs,defStyleAttr);}
    public int getState(){return state;}
    public void setState(int state){this.state=state;}

    @Override
    protected void onDraw(Canvas canvas){
        super.onDraw(canvas);
        int width=getWidth();
        int height=getHeight();
        Paint paint;
        switch (state){
            case SUCCESS:

            paint = new Paint();
            paint.setColor(Color.GREEN);
            paint.setStrokeWidth(20f);
                canvas.drawLine(0,0,width/2,height,paint);
                canvas.drawLine(width/2,height,width,height/2,paint);

                break;
            case exx:
                //drawTriangle(0,0,width,height,invert,Paint ,canvas);
                //Bitmap bitmap = new Bitmap ();
// paint = new Paint();
                //paint.setColor(Color.YELLOW);
               // paint.setStrokeWidth(20f);
              //  red.setColor(android.graphics.Color.RED);
           //     canvas.drawLine(0,0,width/2,height,paint);
             //   canvas.drawLine(width/2,height,width,height/2,paint);
             //   canvas.drawLine(width,height/2,0,0,paint);
               // paint.setStyle(Paint.Style.FILL);

                paint = new Paint();
                int x = 10;
                int y = 20;
                Point p1 = new Point(x,y);
                int pointX = x + width/2;
                int pointY =  y + height;

                Point p2 = new Point(pointX,pointY);
                Point p3 = new Point(x+width,y);


                Path path = new Path();
                path.setFillType(Path.FillType.EVEN_ODD);
                path.moveTo(p1.x,p1.y);
                path.lineTo(p2.x,p2.y);
                path.lineTo(p3.x,p3.y);
                path.close();

                canvas.drawPath(path, paint);



/*
                Path path = new Path();
                path.moveTo(0, 0);new Path();
                path.lineTo(width/2, height);
                path.moveTo(width, height/2);
                path.lineTo(0,0);*/

                //path.moveTo(point3_returned.x, point3_returned.y);
               // path.lineTo(point1_returned.x, point1_returned.y);
             //   path.close();

               // canvas.drawPath(path, paint);
              //  paint.setStyle(Paint.Style.FILL_AND_STROKE);
             //   paint.setStyle(Paint.Style.FILL_AND_STROKE);
                // canvas.drawLine(0,0,width/2,height,paint);
                //canvas.drawLine(width/2,height,width,height/2,paint);

                break;
            case FAILED:
                paint = new Paint();
                paint.setColor(Color.RED);
                paint.setStrokeWidth(20f);

                canvas.drawLine(0,0,width/2,height,paint);
                canvas.drawLine(width/2,height,width,height/2,paint);
                canvas.drawLine(width,height/2,0,0,paint);

                //canvas.drawColor(Color.BLUE, PorterDuff.Mode );
              //  canvas.drawPaint(paint);
                paint.setStyle(Paint.Style.FILL);

            break;
            default:break;








        }
    }
}
