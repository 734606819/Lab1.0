package com.example.trysecond;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.renderscript.ScriptGroup;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.io.Serializable;
import java.net.HttpURLConnection;
import java.net.URL;
import android.renderscript.ScriptGroup.Input;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import static com.example.trysecond.R.layout.activity_main;

public class RequestOperator extends Thread {
    private Context context;
    private Intent intent;

    public interface RequestOperatorListener {
        void success(ModelPost publication);
       // void EX(ModelPost publication);
        void failed(int responseCode);
    }
    private RequestOperatorListener listener;
    private int responseCode;
    public  void  setListener (RequestOperatorListener listener) {this.listener=listener;}

    @Override
    public void run() {
        super.run();
        try {


                ModelPost publication = request();
         //   ex(publication);

            if (publication != null)
                success(publication);
            else
                failed(responseCode);
        } catch (IOException e) {
            Log.e("NetWork",e.toString());
            failed(-1);
        } catch (JSONException e) {
            Log.e("NetWork",e.toString());
            failed(-2);
        }
    }
 private ModelPost request() throws IOException,JSONException{
        URL obj =new URL("http://jsonplaceholder.typicode.com/posts/1");
        HttpURLConnection con =(HttpURLConnection) obj.openConnection();
        con.setRequestMethod("GET");
        con.setRequestProperty("Content-Type","application/json");
        responseCode = con.getResponseCode();
        System.out.println("Response Code" + responseCode);
        InputStreamReader streamReader;
         if (responseCode ==200) {

                  streamReader = new InputStreamReader(con.getInputStream());
         }
         else {    streamReader=new InputStreamReader(con.getErrorStream());}
         BufferedReader in =new BufferedReader(streamReader);
         String inputLine;
         StringBuffer response = new StringBuffer();
         while ((inputLine=in.readLine()) != null) {response.append(inputLine);}
         in.close();
         System.out.println(response.toString());
         if (responseCode ==200)
             return  parsingJsonObject(response.toString());
         else
             return null;
    }

public ModelPost parsingJsonObject(String response) throws JSONException {
        JSONObject object=new JSONObject(response);
    JSONArray terminal_array = new JSONArray();
    JSONArray t_array = terminal_array.put(object);
    int K = t_array.length();
    // List<String>listt=new ArrayList<String>();
    //JSONArray counter=object.getJSONArray(response);
    List<String>listt=new ArrayList<String>();

    if (t_array != null) {
        for (int i=0;i<t_array.length();i++){
            listt.add(t_array.getString(i));

        }
    }

    int c=0;
    for (int i=0;i<t_array.length();i++)
    {
        c++;

    }

        ModelPost post=new ModelPost();
        post.setId(object.optInt("id",0));
        post.setUserId(object.optInt("userId",0));
        post.setTitle(object.getString("title"));
        post.setBodyText(object.getString("body"));
        post.setI(c);
    //Intent i = new Intent(RequestOperator.class,MainActivity.class);
    //System.out.println(K);

    return post;
    }


        private void failed (int code){
            if (listener!=null)
                listener.failed(code);

    //ont sure
        }

        private void success (ModelPost publication){
            if(listener!=null)
                listener.success(publication);
                //ont sure
         }
   // private void ex (ModelPost publication){

         //   listener.EX(publication);
        //ont sure
   //}

 }


