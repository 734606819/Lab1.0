
package com.example.myapplication0;

import java.util.Comparator;
class IgnoreCaseComparator implements Comparator<ListItem> {
    public int compare(ListItem strA, ListItem strB) {
        return strA.getTitle().compareTo(strB.getTitle());

    }
}