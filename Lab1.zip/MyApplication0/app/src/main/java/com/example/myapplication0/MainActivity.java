package com.example.myapplication0;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.DataSetObserver;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
private Button myButton;private Button myButton4; private Button myButton6; private Button Lab2;
private TextView mytextField; int pos=0;
private Button secondActivityButton;
private Context context = this;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myButton=(Button)findViewById(R.id.button);
        myButton4=(Button)findViewById(R.id.button4);
        myButton6=(Button)findViewById(R.id.button6);
        Lab2=findViewById(R.id.lab2B);
        Lab2.setOnClickListener(new  View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentcc = new Intent(MainActivity.this, Lab2.class);
                // intent.putExtras(bundle);
                startActivity(intentcc);


            }

        });
        myButton4.setOnClickListener(new  View.OnClickListener() {
            @Override
            public void onClick(View view) {
                myButton4.setVisibility(View.INVISIBLE);


            }

        });

        myButton6.setOnClickListener(new  View.OnClickListener() {
            @Override
            public void onClick(View view) {
                 Intent intentcc = new Intent(MainActivity.this, BirthdayC.class);
                // intent.putExtras(bundle);
                 startActivity(intentcc);



            }

        });




        myButton.setOnClickListener(start);
     //  Intent intent=getIntent();
     //  pos=intent.getExtras().getInt("Position");

       //final ImageView img = findViewById(R.id.imageView3);
     //  final TextView name = findViewById(R.id.editText3);
       // final TextView des = findViewById(R.id.editText4);
    }
    public void runSecondActivity(boolean b) {
        Intent intent = new Intent(context, sEC.class);
        intent.putExtra("flag", b);
        context.startActivity(intent);
    }
    View.OnClickListener start = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            runSecondActivity(true);
        }
    };


    }

