package com.example.myapplication0;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.nfc.Tag;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.Collection;
import java.util.Collections;
import java.io.Serializable;
import java.security.Key;
import java.util.ArrayList;
import java.util.List;

public class sEC extends AppCompatActivity implements Serializable {
    private EditText A;
    private EditText B;
    private ListView myList;
    private ListAdapter adapter;
    private Button button;
    private Adapter sm;
    private Button buttonp;
    private Button button5;
    public static final String EXTRA_COUNTRY = "EXTRA_COUNTRY";
    private static final int REQUEST_RESPONSE = 1;
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_s_ec);
        button5=findViewById(R.id.button55);
        myList = findViewById(R.id.listView);
        button = findViewById(R.id.button2);
        final List<ListItem> items = new ArrayList<ListItem>();
        final Intent intent = getIntent();
        A = findViewById(R.id.editText4);
        B = findViewById(R.id.editText3);
       buttonp= findViewById(R.id.button3);
        if (intent.getBooleanExtra("flag", true)) {
           ListItem A1 = new ListItem("GA", R.drawable.ic_launcher_background, "FW");
         ListItem A2 = new ListItem("Jane", R.drawable.ic_launcher_background, "Physics");
            ListItem A3 = new ListItem("Jack", R.drawable.ic_launcher_background, "Math");
            ListItem A4 = new ListItem("EZ", R.drawable.ic_launcher_background, "GOOD");
            items.add(A1);  items.add(A2);  items.add(A3);  items.add(A4);
            //items.add(new ListItem("GA", R.drawable.ic_launcher_background, "FW"));
         //   items.add(new ListItem("Jane", R.drawable.ic_launcher_background, "Physics"));
          //  items.add(new ListItem("Jack", R.drawable.ic_launcher_background, "Math"));
          //  items.add(new ListItem("EZ", R.drawable.ic_launcher_background, "GOOD"));
        } else {
            items.add(new ListItem("Math", R.drawable.ic_launcher_background, "GG"));
            items.add(new ListItem("ASDSAD", R.drawable.ic_launcher_background, "ASDSAD"));
            items.add(new ListItem("WEQWE", R.drawable.ic_launcher_background, "FQWESA"));
            items.add(new ListItem("FQWDQW", R.drawable.ic_launcher_background, "RWQEQWE"));
            items.add(new ListItem("Math", R.drawable.ic_launcher_background, "GG"));

        }

        String CC= A.getText().toString();
        String BB=B.getText().toString();
        //Intent intent = new Intent(sEC.this, Third.class);
        // public void onItemClick(int position){
        //    Log.d(Tag,"onItemClick:clicked"+position);//
        Bundle bundle = new Bundle();
       // bundle.putParcelableArrayList("list", items);
        //  }
        //
       // Bundle b = new Bundle();b.putSerializable("list", items);
        adapter = new Adapter(this, items);
        myList.setAdapter(adapter);
        button5.setOnClickListener(new  View.OnClickListener() {
            @Override
            public void onClick(View view) {
                items.remove(0);
                //    IgnoreCaseComparator icc = new IgnoreCaseComparator();



                myList.setAdapter(adapter);
                //    java.util.Collections.sort(items,icc);

            }

        });
        buttonp.setOnClickListener(new  View.OnClickListener() {
            @Override
            public void onClick(View view) {
                 Collections.sort(items,new IgnoreCaseComparator());
                //    IgnoreCaseComparator icc = new IgnoreCaseComparator();
                myList.setAdapter(adapter);
          //    java.util.Collections.sort(items,icc);

                }

        });
        myList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int pos, long id) {

              //  Intent intent = new Intent(sEC.this, Third.class);
                Intent intent = new Intent(sEC.this , Third.class) ;
                Intent intentcc= new Intent(sEC.this,ACC.class);
                ListItem mPerson = new ListItem() ;
                //  mPerson.setTitle("JackChen");
                mPerson.setTitle(items.get(pos).getTitle());
                mPerson.setDescription(items.get(pos).getDescription());
                mPerson.setImageId(items.get(pos).getImageId());
                intent.putExtra("AAA", mPerson);
                intentcc.putExtra("AAA", mPerson);
              String AL =items.get(pos).getTitle();
              String AP = items.get(pos).getDescription();
              int PP = items.get(pos).getImageId();
                intent.putExtra("qa", AL);
                intent.putExtra("qq", AP);intent.putExtra("qqq", PP);
                  intentcc.putExtra("q", AL); intentcc.putExtra("qq", AP); intentcc.putExtra("qqq", PP);
                //  bundle.putSerializable("key" , mPerson);
                //  intent.putExtras(bundle) ;
                startActivity(intent);
              //  bundle.putParcelableArrayList("list",items);
           //bundle.putSerializable("arrayList",items );
               // Intent intent = new Intent(sEC.this, Third.class);
               // intent.putExtras(bundle);
             //   startActivity(intent);



                //    super.onItemClick(parent, view, pos, id);
            //    Intent i = new Intent(getBaseContext(), Third.class);
             //   i.putExtra("var", (String) myList.getAdapter().getItem(pos));
              //  startActivity(i);

                //  final Object objSent = new Object();
                //  final Bundle bundle = new Bundle();
                // bundle.putBundle("object_value", new (objSent));
                // startActivity(new Intent(sEC.this, Third.class).putExtras(bundle));
                //   Log.d(,"original object=" + objSent);
                //Intent intent = new Intent();
                //  intent.putExtra("itemInfo",ListItem);
                //  setResult(1,intent);
                //    finish();
                //    ListItem dene = new ListItem(2,"Mustafa");
                // Intent i = new Intent(sEC.this, Third.class);
                // i.putExtra("sampleObject", dene);
                // startActivity(i);
                ////  String KK = B.getText().toString();
                ////  Intent i = new Intent(sEC.this, Third.class);
                /////   i.putExtra ("Gettitle",KK);
                // intent.putExtra ("Gettitle",getDescription());
                //      startActivityForResult(intent, REQUEST_RESPONSE);

                //  Intent intent = new Intent(getApplicationContext(),Third.class);

                // startActivity(i);

                //    String TempListViewClickedValue = items[position].toString();
                //   ItemClicked item = adapter.getItemAtPosition(position);

                //    Intent intent = new Intent(sEC.this, MainActivity.class);

                // intent.putExtra("get", aList.get(position));


                //  String result = (String) myList.getItemAtPosition(position).toString();
                //   intent.putExtra("get", result);
                // startActivity(intent);

                // Intent i = new Intent(getApplicationContext(), MainActivity.class);
                //  Intent intent = new Intent(getApplicationContext(), MainActivity.class);


                //startActivity(intent);


            }

        });
        button.setOnClickListener(new  View.OnClickListener() {
                @Override
                public void onClick(View view) { final String AC = A.getText().toString();
                    final String BC = B.getText().toString();
                    items.add(new ListItem(AC, R.drawable.ic_launcher_background, BC));
                    myList.setAdapter(adapter);
                }

        });
    }}