package com.example.myapplication0;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class BirthdayC extends AppCompatActivity {
private ProgressDialog statusDialog;
private Activity sendMailActivity;
        Button marin;
        Button startBtn;
        DatePicker picker;
        Button btnGet;
        TextView tvw;
@Override
protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_birthday_c);
        marin=findViewById(R.id.Jo);
        //
        startBtn = (Button) findViewById(R.id.button8);
        startBtn.setOnClickListener(new View.OnClickListener() {
        public void onClick(View view){
            sendEmail();
        }});
        //
        tvw=(TextView)findViewById(R.id.textView5);
        picker=(DatePicker)findViewById(R.id.datePicker1);
        btnGet=(Button)findViewById(R.id.button7);
        btnGet.setOnClickListener(new View.OnClickListener() {
@Override
public void onClick(View v) {
        tvw.setText("Selected Date: "+ picker.getDayOfMonth()+"/"+ (picker.getMonth() + 1)+"/"+picker.getYear());
        }
        });

        marin.setOnClickListener(new  View.OnClickListener() {
            @Override
            public void onClick(View view) {
                  Intent intentccc = new Intent(BirthdayC.this, BirthdayMarin.class);
                // intent.putExtras(bundle);
                  startActivity(intentccc);
            }
        });
}


//
    protected void sendEmail() {
        Log.i("Send email", "");
        String[] TO = {""};
        String[] CC = {""};
        Intent emailIntent = new Intent(Intent.ACTION_SEND);

        emailIntent.setData(Uri.parse("mailto:"));
        emailIntent.setType("text/plain");
        emailIntent.putExtra(Intent.EXTRA_EMAIL, TO);
        emailIntent.putExtra(Intent.EXTRA_CC, CC);
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Your subject");
   //     emailIntent.putExtra(Intent.EXTRA_TEXT, "Email message goes here");

        try {
            startActivity(Intent.createChooser(emailIntent, "Send mail..."));
            finish();
            Log.i("Finished sending ..", "");
        } catch (android.content.ActivityNotFoundException ex) {
            Toast.makeText(BirthdayC.this, "There is no email client installed.", Toast.LENGTH_SHORT).show();
        }
    }


}









