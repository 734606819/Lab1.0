package com.example.myapplication0;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class ACC extends AppCompatActivity {
    private TextView ccc;private ListView myList1;private ListAdapter adapter11; private TextView cccc; private ImageView ccccc;
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_acc);

          //  String AAL =getIntent().getSerializableExtra("q").toString();
            Intent i=getIntent();
            setContentView(R.layout.activity_third);
            ccc= findViewById(R.id.textView4);
            cccc=findViewById(R.id.textView3);
            ccccc=findViewById(R.id.imageView2);
             Intent intent1= getIntent();

     //   List<ListItem> items11 = new ArrayList<ListItem>();
      //  ListItem movie1 = (ListItem) getIntent().getSerializableExtra("AAA");

      //  ccc.setText(movie1.getTitle().toString());
   //  String id =movie1.getTitle().toString();
      //  ccc.setText(id);
       // ccc.setText("Escriba su mensaje y luego seleccione el canal.");
       //    myList1 = findViewById(R.id.listView11);
          //  Intent intent = getIntent();
        //   List<ListItem> items1 = new ArrayList<ListItem>();
         //  ListItem movie = (ListItem) getIntent().getSerializableExtra("AAA");
         //  items1.add(movie);
          // myList1.setAdapter(adapter11);
    }
}
