package com.example.myapplication0;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;

import java.io.Serializable;import android.content.Context;
import android.content.Intent;
import android.nfc.Tag;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.Collection;
import java.util.Collections;
import java.io.Serializable;
import java.security.Key;
import java.util.ArrayList;
import java.util.List;

public class Marin_seeting extends AppCompatActivity implements Serializable {
    Button save;
    EditText ed1;
    EditText ed2;
    EditText ed3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_marin_seeting);
        save=findViewById(R.id.save);
        ed1=findViewById(R.id.ed1);
        ed2=findViewById(R.id.ed2);
        ed3=findViewById(R.id.ed3);
        save.setOnClickListener(new  View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String ed1S=ed1.getText().toString();
                String ed2S=ed2.getText().toString();
                String ed3S=ed3.getText().toString();
                Intent intent = new Intent(Marin_seeting.this, BirthdayMarin.class);
                // intent.putExtras(bundle);
                String Ab="dd";
                intent.putExtra("AAA", ed1S);
                intent.putExtra("BBB", ed2S);
                intent.putExtra("CCC",ed3S);
                intent.putExtra("ddd", Ab);
                startActivity(intent);
    }
});}}
