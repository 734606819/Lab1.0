package com.example.myapplication0;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;

import java.io.Serializable;
import android.content.Context;
import android.content.Intent;
import android.nfc.Tag;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.Collection;
import java.util.Collections;
import java.io.Serializable;
import java.security.Key;
import java.util.ArrayList;
import java.util.List;
public class BirthdayMarin extends AppCompatActivity {
    Button buttonS;
    EditText ed1;
    EditText ed2;
    EditText ed3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_birthday_marin);
        buttonS=findViewById(R.id.setting);
        ed1=findViewById(R.id.ed11);
        ed2=findViewById(R.id.ed22);
        ed3=findViewById(R.id.ed33);
       //String AAL =getIntent().getSerializableExtra("Ab").toString();
        buttonS.setOnClickListener(new  View.OnClickListener() {
            @Override

            public void onClick(View view) {
                Intent intentccc = new Intent(BirthdayMarin.this, Marin_seeting.class);
                // intent.putExtras(bundle);
                startActivity(intentccc);



            }

        });
       // Bundle b = getIntent().getExtras();
       // if(b != null)
          // String A =  b.getSerializable("AAA");
       // Bundle extras = getIntent().getExtras();
        //String ED1 = intengetSerializableExtra("AAA");
       // Intent intent = getIntent ();
      // String AAAL =getIntent().getSerializableExtra("BBB").toString();
       //String AAAAL =getIntent().getSerializableExtra("CCC").toString();

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            if (extras.containsKey("AAA")) {
                String ED1 = extras.getSerializable("AAA").toString();
                ed1.setText(ED1);
            }
            if (extras.containsKey("BBB")) {
                String ED2 = extras.getSerializable("BBB").toString();
                ed2.setText(ED2);
            }
            if (extras.containsKey("CCC")) {
                String ED3 = extras.getSerializable("CCC").toString();
                ed3.setText(ED3);
            }
        }



    }
}
