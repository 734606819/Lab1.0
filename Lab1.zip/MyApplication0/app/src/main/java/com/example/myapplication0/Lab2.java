package com.example.myapplication0;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.renderscript.ScriptGroup;

import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import android.renderscript.ScriptGroup.Input;
import java.io.IOException;
import java.io.InputStreamReader;
public class Lab2 extends AppCompatActivity implements RequestOperator.RequestOperatorListener {
    Button sendRequestButton;
    TextView title;
    EditText bodyText;
    EditText editText7;
    private ModelPost publication;
    private IndicatingView indicator;
    // private void sendRequest(){RequestOperator ro =new RequestOperator();
    //  ro.setListener(this);
    // ro.start();}
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab2);
        indicator=(IndicatingView) findViewById(R.id.generated_graphic);
        sendRequestButton = findViewById(R.id.buttondianji);
        sendRequestButton.setOnClickListener(requestButtonClicked);
        title = findViewById(R.id.textView11);
        bodyText = findViewById(R.id.editText11);
        editText7=findViewById(R.id.editText7);


    }

    View.OnClickListener requestButtonClicked = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            sendRequest();
        }
    };

    private void sendRequest() {
        //  setContentView(R.layout.activity_main);
        //   ProgressBar pb = (ProgressBar) findViewById(R.id.pbLoading);
        //  pb.setVisibility(ProgressBar.VISIBLE);
// run a background job and once complete

        //  pb.setVisibility(ProgressBar.INVISIBLE);
        RequestOperator ro = new RequestOperator();
        ro.setListener(this);
        ro.start(); }
    public void updatePublication () {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (publication != null) {
                    title.setText(publication.getTitle());
                    bodyText.setText(publication.getBodyText());

                } else {
                    title.setText("");
                    bodyText.setText("");

                }
            }
        });
    }
    @Override
    public void success(ModelPost publication) {this.publication=publication;
        setIndicatorStatus(IndicatingView.SUCCESS);
        updatePublication();}
    @Override
    public void failed(int responseCode) {this.publication=null;
        setIndicatorStatus(IndicatingView.FAILED);
        updatePublication();}

    public void setIndicatorStatus(final int status) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                indicator.setState(status);
                indicator.invalidate();
            }
        });

    }
}




