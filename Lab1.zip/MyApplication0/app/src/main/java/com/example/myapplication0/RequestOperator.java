package com.example.myapplication0;
import android.renderscript.ScriptGroup;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import android.renderscript.ScriptGroup.Input;
import android.util.Log;

import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
public class RequestOperator extends Thread {

    public interface RequestOperatorListener {
        void success(ModelPost publication);

        void failed(int responseCode);
    }
    private RequestOperatorListener listener;
    private int responseCode;
    public  void  setListener (RequestOperatorListener listener) {this.listener=listener;}

    @Override
    public void run() {
        super.run();
        try {
            ModelPost publication = request();
            if (publication != null)
                success(publication);
            else
                failed(responseCode);
        } catch (IOException e) {
            Log.e("NetWork",e.toString());
            failed(-1);
        } catch (JSONException e) {
            Log.e("NetWork",e.toString());
            failed(-2);
        }
    }
    private ModelPost request() throws IOException,JSONException{
        URL obj =new URL("http://jsonplaceholder.typicode.com/posts/1");
        HttpURLConnection con =(HttpURLConnection) obj.openConnection();
        con.setRequestMethod("GET");
        con.setRequestProperty("Content-Type","application/json");
        responseCode = con.getResponseCode();
        System.out.println("Response Code" + responseCode);
        InputStreamReader streamReader;
        if (responseCode ==200) {
            streamReader = new InputStreamReader(con.getInputStream());
        }
        else {    streamReader=new InputStreamReader(con.getErrorStream());}
        BufferedReader in =new BufferedReader(streamReader);
        String inputLine;
        StringBuffer response = new StringBuffer();
        while ((inputLine=in.readLine()) != null) {response.append(inputLine);}
        in.close();
        System.out.println(response.toString());
        if (responseCode ==200)
            return  parsingJsonObject(response.toString());
        else
            return null;
    }
    public ModelPost parsingJsonObject(String response) throws JSONException {
        JSONObject object=new JSONObject(response);
        //houjia
        /*List<String>listt=new ArrayList<String>();
   // JSONArray
       //int i=0;
       JSONArray counter=object.getJSONArray(response);
       for (int i=0;i<counter.length();i++)
       {  listt.add(counter.getJSONObject(i).getString(response));}
          int KZ=listt.size();
*/

//
        ModelPost post=new ModelPost();
        post.setId(object.optInt("id",0));
        post.setUserId(object.optInt("userId",0));
        post.setTitle(object.getString("title"));
        post.setBodyText(object.getString("body"));
        return post;
    }
    private void failed (int code){
        if (listener!=null)
            listener.failed(code);

        //ont sure
    }

    private void success (ModelPost publication){
        if(listener!=null)
            listener.success(publication);
        //ont sure
    }

}



