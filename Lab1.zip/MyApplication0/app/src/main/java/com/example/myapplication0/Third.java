package com.example.myapplication0;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class Third extends AppCompatActivity {
    private EditText cc;private ListView myList1;private ListAdapter adapter1;   private TextView kppp;private TextView kpppp; private ImageView kppppp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       // Intent i=getIntent();
        setContentView(R.layout.activity_third);
        cc= findViewById(R.id.editText4);
        myList1 = findViewById(R.id.listView11);
        Intent intent = getIntent();
        List<ListItem> items1 = new ArrayList<ListItem>();
        ListItem movie = (ListItem) getIntent().getSerializableExtra("AAA");
        items1.add(movie);
        adapter1 = new Adapter(this, items1);
        myList1.setAdapter(adapter1);
        String AAL =getIntent().getSerializableExtra("qa").toString();
        String AAAL =getIntent().getSerializableExtra("qq").toString();
        String AAAAL =getIntent().getSerializableExtra("qqq").toString();
        int result = Integer.parseInt(AAAAL);
        kppp= findViewById(R.id.textView3);
        kpppp= findViewById(R.id.textView4);
        kppppp=findViewById(R.id.imageView2);
        kppp.setText(AAL); kpppp.setText(AAAL); kppppp.setImageResource(result);

        //
        //Bundle bundle = getIntent().getExtras();
       // String var = bundle.getString("var");
      //  cc.setText(i.getStringExtra("Gettitle"));
       // cc.setText(var);
    }
}
