package com.example.myapplication0;
import android.renderscript.ScriptGroup;

import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import android.renderscript.ScriptGroup.Input;
import java.io.IOException;
import java.io.InputStreamReader;
public class ModelPost {
    int id;
    int userId;
    String title;
    String bodyText;


    public ModelPost(){ }
    public ModelPost (int id,int userId,String title,String bodyText){
        this.id=id;
        this.userId=userId;
        this.title=title;
        this.bodyText=bodyText;

    }
    public int getId(){return id;}
    public void setId(int id) {this.id=id;}
    public int getUserId(){return userId; }
    public void setUserId(int userId){this.userId=userId;}
    public String getTitle(){return title;}
    public void setTitle(String title){this.title=title;}
    public String getBodyText(){return bodyText;}
    public void setBodyText(String bodyText){this.title=bodyText;}






}
