package com.example.lab3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.hardware.Camera;
import android.hardware.GeomagneticField;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.jakewharton.rxbinding3.view.RxView;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.concurrent.TimeUnit;

import kotlin.Unit;
import kotlin.jvm.internal.FloatSpreadBuilder;

public class MainActivity extends AppCompatActivity implements SensorEventListener, LocationListener {
    private SensorManager senSensorManager;
    private Sensor senAccelerometer;
    private TextView xValue, yValue, zValue;
    private Button startandStop;
    private Button Canmpass, Coordi;
    Button wudi;
    TextView PPP,OOO,III;
    private LocationManager locationManager;
    private TextView coor;
    //????
    public static final int TAKE_PHOTO=1;
    private final int CAMERA_REQUEST = 8888;
    private ImageView picture;
TextView kkkk;
    private Uri ImageUri;









    private boolean InformationObtained;
    GeomagneticField geoField;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        InformationObtained = false;
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

wudi=findViewById(R.id.wudi);
        wudi.setOnClickListener(wudii);
        startandStop = findViewById(R.id.start_and_stop);
        startandStop.setOnClickListener(StartAndStopButtonListener);
        senSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        senAccelerometer = senSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        Canmpass = findViewById(R.id.campass);
        coor = findViewById(R.id.coordinates);
        Canmpass.setOnClickListener(campass);
        Coordi = findViewById(R.id.coordi);
        Coordi.setOnClickListener(coooo);
        xValue = findViewById(R.id.x_value);
        yValue = findViewById(R.id.y_value);
        zValue = findViewById(R.id.z_value);
        picture=findViewById(R.id.imageView);
        PPP=findViewById(R.id.PPP);
        OOO=findViewById(R.id.OOO);
        III=findViewById(R.id.III);
        PPP.setText(String.valueOf(9));
        OOO.setText(String.valueOf(0));
        III.setText(String.valueOf(0));
        //picture=findViewById(R.id.picture);

        getCurrentLocation();
    }

    View.OnClickListener coooo = new View.OnClickListener() {

        @Override
        public void onClick(View v) {
        //    getDeviceLoc();
            if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CAMERA)
                    == PackageManager.PERMISSION_DENIED) {
                ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.CAMERA}, 1);
            }
           // Runnable closeThread = new Runnable() {
                // 将要执行的操作写在线程对象的run方法当中
               // public void run() {
               //     flashclose();
               //     try {
               //         Thread.sleep(100);
               //     } catch (InterruptedException e) {
// TODO Auto-generated catch block
              //          e.printStackTrace();
              //      }
                  //  handler.post(closeThread);

            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    Camera cam = Camera.open();
                    Camera.Parameters p = cam.getParameters();
                    p.setFlashMode(Camera.Parameters.FLASH_MODE_TORCH);
                    cam.setParameters(p);
                    cam.startPreview();

                }
            }, 100);

            Handler handler2 = new Handler();
            handler2.postDelayed(new Runnable() {
                @Override
                public void run() {
                    Camera cam = Camera.open();
                    Camera.Parameters p = cam.getParameters();
                    p.setFlashMode(Camera.Parameters.FLASH_MODE_OFF);
                    cam.setParameters(p);
                    cam.startPreview();
                }
            }, 100);

            Handler handler4 = new Handler();
            handler4.postDelayed(new Runnable() {
                @Override
                public void run() {
                    Camera cam = Camera.open();
                    Camera.Parameters p = cam.getParameters();
                    p.setFlashMode(Camera.Parameters.FLASH_MODE_TORCH);

                    cam.setParameters(p);
                    cam.startPreview();
                }
            }, 100);



            Handler handler3 = new Handler();
            handler3.postDelayed(new Runnable() {
                @Override
                public void run() {
                    Camera cam = Camera.open();
                    Camera.Parameters p = cam.getParameters();
                    p.setFlashMode(Camera.Parameters.FLASH_MODE_OFF);
                    cam.setParameters(p);
                    cam.startPreview();
                }
            }, 100);
            Handler handler5 = new Handler();
            handler5.postDelayed(new Runnable() {
                @Override
                public void run() {
                    Camera cam = Camera.open();
                    Camera.Parameters p = cam.getParameters();
                    p.setFlashMode(Camera.Parameters.FLASH_MODE_TORCH);

                    cam.setParameters(p);
                    cam.startPreview();
                }
            }, 100);
            Handler handler6 = new Handler();
            handler6.postDelayed(new Runnable() {
                @Override
                public void run() {
                    Camera cam = Camera.open();
                    Camera.Parameters p = cam.getParameters();
                    p.setFlashMode(Camera.Parameters.FLASH_MODE_OFF);
                    cam.setParameters(p);
                    cam.startPreview();
                }
            }, 100);




            Handler handler22 = new Handler();
            handler22.postDelayed(new Runnable() {
                @Override
                public void run() {
                    Camera cam = Camera.open();
                    Camera.Parameters p = cam.getParameters();
                    p.setFlashMode(Camera.Parameters.FLASH_MODE_TORCH);
                    cam.setParameters(p);
                    cam.startPreview();
                }
            }, 1000);

            Handler handler23 = new Handler();
            handler23.postDelayed(new Runnable() {
                @Override
                public void run() {
                    Camera cam = Camera.open();
                    Camera.Parameters p = cam.getParameters();
                    p.setFlashMode(Camera.Parameters.FLASH_MODE_OFF);
                    cam.setParameters(p);
                    cam.startPreview();
                }
            }, 20000);

            Handler handler24 = new Handler();
            handler24.postDelayed(new Runnable() {
                @Override
                public void run() {
                    Camera cam = Camera.open();
                    Camera.Parameters p = cam.getParameters();
                    p.setFlashMode(Camera.Parameters.FLASH_MODE_TORCH);

                    cam.setParameters(p);
                    cam.startPreview();
                }
            }, 100);
            Handler handler25 = new Handler();
            handler25.postDelayed(new Runnable() {
                @Override
                public void run() {
                    Camera cam = Camera.open();
                    Camera.Parameters p = cam.getParameters();
                    p.setFlashMode(Camera.Parameters.FLASH_MODE_OFF);
                    cam.setParameters(p);
                    cam.startPreview();
                }
            }, 20000);
            Handler handler26 = new Handler();
            handler26.postDelayed(new Runnable() {
                @Override
                public void run() {
                    Camera cam = Camera.open();
                    Camera.Parameters p = cam.getParameters();
                    p.setFlashMode(Camera.Parameters.FLASH_MODE_TORCH);

                    cam.setParameters(p);
                    cam.startPreview();
                }
            }, 100);
            Handler handler27 = new Handler();
            handler27.postDelayed(new Runnable() {
                @Override
                public void run() {
                    Camera cam = Camera.open();
                    Camera.Parameters p = cam.getParameters();
                    p.setFlashMode(Camera.Parameters.FLASH_MODE_ON);
                    p.setFlashMode(Camera.Parameters.FLASH_MODE_OFF);
                    p.setFlashMode(Camera.Parameters.FLASH_MODE_ON);
                    p.setFlashMode(Camera.Parameters.FLASH_MODE_OFF);
                    p.setFlashMode(Camera.Parameters.FLASH_MODE_ON);
                    p.setFlashMode(Camera.Parameters.FLASH_MODE_OFF);
                    cam.setParameters(p);
                    cam.startPreview();
                }
            }, 2000);















            Handler handler7 = new Handler();
            handler7.postDelayed(new Runnable() {
                @Override
                public void run() {
                    Camera cam = Camera.open();
                    Camera.Parameters p = cam.getParameters();
                    p.setFlashMode(Camera.Parameters.FLASH_MODE_TORCH);
                    cam.setParameters(p);
                    cam.startPreview();
                }
            }, 100);

            Handler handler8 = new Handler();
            handler8.postDelayed(new Runnable() {
                @Override
                public void run() {
                    Camera cam = Camera.open();
                    Camera.Parameters p = cam.getParameters();
                    p.setFlashMode(Camera.Parameters.FLASH_MODE_OFF);
                    cam.setParameters(p);
                    cam.startPreview();
                }
            }, 100);

            Handler handler9 = new Handler();
            handler9.postDelayed(new Runnable() {
                @Override
                public void run() {
                    Camera cam = Camera.open();
                    Camera.Parameters p = cam.getParameters();
                    p.setFlashMode(Camera.Parameters.FLASH_MODE_TORCH);

                    cam.setParameters(p);
                    cam.startPreview();
                }
            }, 100);
            Handler handler10 = new Handler();
            handler10.postDelayed(new Runnable() {
                @Override
                public void run() {
                    Camera cam = Camera.open();
                    Camera.Parameters p = cam.getParameters();
                    p.setFlashMode(Camera.Parameters.FLASH_MODE_OFF);
                    cam.setParameters(p);
                    cam.startPreview();
                }
            }, 100);
            Handler handler11 = new Handler();
            handler11.postDelayed(new Runnable() {
                @Override
                public void run() {
                    Camera cam = Camera.open();
                    Camera.Parameters p = cam.getParameters();
                    p.setFlashMode(Camera.Parameters.FLASH_MODE_TORCH);

                    cam.setParameters(p);
                    cam.startPreview();
                }
            }, 100);
            Handler handler12 = new Handler();
            handler12.postDelayed(new Runnable() {
                @Override
                public void run() {
                    Camera cam = Camera.open();
                    Camera.Parameters p = cam.getParameters();
                    p.setFlashMode(Camera.Parameters.FLASH_MODE_OFF);
                    cam.setParameters(p);
                    cam.startPreview();
                }
            }, 100);



        }
    };
    View.OnClickListener campass = new View.OnClickListener() {

        @Override
        public void onClick(View v) {
            Intent intent = new Intent(MainActivity.this, Campass.class);
            startActivity(intent);
        }
    };
    View.OnClickListener wudii = new View.OnClickListener() {

        @Override
        public void onClick(View v) {
            Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(cameraIntent, CAMERA_REQUEST);
        }};

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == CAMERA_REQUEST && resultCode == RESULT_OK) {
            Bitmap photo = (Bitmap) data.getExtras().get("data");
            picture.setImageBitmap(photo);
        }

        };





                View.OnClickListener StartAndStopButtonListener = new View.OnClickListener() {

        @Override
        public void onClick(View v) {



            if (senAccelerometer == null) {
                Toast.makeText(MainActivity.this, "noSensor", Toast.LENGTH_LONG).show();
                return;
            }
            if (InformationObtained) {
                startandStop.setText("start");
                senSensorManager.unregisterListener(MainActivity.this, senAccelerometer);
                InformationObtained = false;
            } else {
                senSensorManager.registerListener(MainActivity.this, senAccelerometer, SensorManager.SENSOR_DELAY_NORMAL);
                startandStop.setText("stop");
                InformationObtained = true;
            }
        }
    };

    @Override
    public void onSensorChanged(SensorEvent event) {
       /* RxView.clicks(xValue).throttleFirst(2,TimeUnit.SECONDS).subscribe(new io.reactivex.Observer<Unit>() {
            @Override

            public void onSubscribe(io.reactivex.disposables.Disposable d) {  Log.d("-----rxjava", "开始采用subscribe连接");

            }



                                                                              @Override

                                                                              public void onNext(Unit unit) {

                                                                                  Log.d("-----rxjava", "对Next事件作出响应:" + unit);

                                                                              }

                                                                              @Override

                                                                              public void onError(Throwable e) {

                                                                                  Log.d("-----rxjava", "对Error事件作出响应" + e);

                                                                              } @Override

                                                                              public void onComplete() {

                                                                                  Log.d("-----rxjava", "对onComplete事件作出响应:RxJava认识完成");

                                                                              }  });


*/
        kkkk=findViewById(R.id.siii);
        String KK="";
        String UU="";
        String ss="";
         Sensor mySensor = event.sensor;
        if (mySensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            if (event.values[0] >= 0) {
                xValue.setText(new DecimalFormat("##.#").format(event.values[0]) );
               KK="left";
            } else {
                xValue.setText(new DecimalFormat("##.#").format(event.values[0]));
               KK="right";
            }
            if (event.values[1] >= 0) {
                yValue.setText(new DecimalFormat("##.#").format(event.values[1]) );
              UU="up";
            } else {
                yValue.setText(new DecimalFormat("##.#").format(event.values[1]) );
                UU="down";
            }

            if (event.values[2] >= 0) {
                zValue.setText(new DecimalFormat("##.#").format(event.values[2]) );
                ss="Screen up";
            } else {
                zValue.setText(new DecimalFormat("##.#").format(event.values[2]) );
                ss="Screen down";
            }

            kkkk.setText(KK+" "+UU+"  "+ss+"  ");
            String C = Float.toString(event.values[0]);
            Double  Carbs=Double.valueOf(C).doubleValue();
            String c =PPP.getText().toString();
            Double  carbs=Double.valueOf(c).doubleValue();
            String cc =III.getText().toString();
            Double  carbss=Double.valueOf(cc).doubleValue();
            String ccc =OOO.getText().toString();
            Double  carbsss=Double.valueOf(ccc).doubleValue();

            if (Math.abs(Math.abs(event.values[2])-Math.abs(carbs))>=0.5) {
               PPP.setText(new DecimalFormat("##.#").format(event.values[2]));
            }
            if (Math.abs(Math.abs(event.values[1])-Math.abs(carbss))>=0.5) {
                III.setText(new DecimalFormat("##.#").format(event.values[1]));
            }

            if (Math.abs(Math.abs(event.values[0])-Math.abs(carbsss))>=0.5) {
                OOO.setText(new DecimalFormat("##.#").format(event.values[0]));
            }








            if ( event.values[1] >= 8.7 ) { WindowManager.LayoutParams ggg = getWindow().getAttributes();
                ggg.screenBrightness = 1;
                getWindow().setAttributes(ggg);}
            if ( event.values[1] >= -1 && event.values[1]<=1) {
                WindowManager.LayoutParams lp = getWindow().getAttributes();
                lp.screenBrightness = 0;
                getWindow().setAttributes(lp);
                //WindowManager.LayoutParams lp = getWindow().getAttributes();
                //lp.screenBrightness = 1;
                //getWindow().setAttributes(lp);

            }

            //double X,Y,Z;
            // X=event.values[0];
            // // Y=event.values[1];
            //  Z=event.values[2];
            //  if ()

        }

    }

    //double X,Y,Z;


    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    @Override
    protected void onPause(){
        super.onPause();
        if (senAccelerometer !=null)
            senSensorManager.unregisterListener(MainActivity.this,senAccelerometer);
if(ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)!= PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this,Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED)
{ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION},1);
    ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION},1); }
this.locationManager.removeUpdates(this);
    }
    @Override
    protected void onResume(){
        super.onResume();
        if(senAccelerometer !=null && InformationObtained)
            senSensorManager.registerListener(MainActivity.this,senAccelerometer,SensorManager.SENSOR_DELAY_NORMAL);
        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)!= PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this,Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED)
        {ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION},1);
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION},1);
        }
//        this.locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,400,1,this);
    }

    @Override
    public void onLocationChanged(Location location) {

          //  if (location == null) {
                coor.setText("Coordinates :" +" " +location.getLatitude()+" "+"coordinate"+location.getLatitude());
           // }
        }


    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
        Log.d("Latitude","status");
    }

    @Override
    public void onProviderEnabled(String provider) {
        Log.d("Latitude","enable");
    }

    @Override
    public void onProviderDisabled(String provider) {
        Log.d("Latitude","disable");
    }


    private Location getDeviceLoc() {
        if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission
                (MainActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
           // ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, 0);
        } else {
            Location location = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            Location location1 = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            Location location2 = locationManager.getLastKnownLocation(LocationManager.PASSIVE_PROVIDER);
            if (location != null) {
                return location;
            } else if (location1 != null) {
                return location1;
            } else if (location2 != null) {
                return location2;
            } else {
                Toast.makeText(this, "Unable to trace your location", Toast.LENGTH_SHORT).show();
            }
        }
        return null;
    }
    private void getCurrentLocation() {
        Log.e("getLocation","Called");

        LocationManager locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
        LocationListener locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                Double mlat = location.getLatitude();
                Double mlon = location.getLongitude();
                String mLogn = Double.toString(mlon);
                String mLatd = Double.toString(mlat);
                Log.e("mLogn",""+mLogn);
                Log.e("mLatd",""+mLatd);
                mLogn=mLogn.trim();
                mLatd=mLatd.trim();
                if (mLatd==null || mLogn==null) {
                    if (mLatd.isEmpty()) {
                        mLatd = "No data found";
                    }
                    if (mLogn.isEmpty()) {
                        mLogn = "No data found";
                    }
                }

                // Log.e("Location",""+mlon+" "+mlat);
//                Toast.makeText(CampaignTrain.this, "your location is " + mLogn + " " + mLatd, Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onStatusChanged(String s, int i, Bundle bundle) {

            }

            @Override
            public void onProviderEnabled(String s) {

            }

            @Override
            public void onProviderDisabled(String s) {

            }
        };
        String locationProvide = LocationManager.NETWORK_PROVIDER;
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED ) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION},1);
                return;
            }


        }
        if ( ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED){
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},1);
                return;
            }

        }
        locationManager.requestLocationUpdates(locationProvide, 0, 0, locationListener);
        Location lastLocation=locationManager.getLastKnownLocation(locationProvide);


    }
}

